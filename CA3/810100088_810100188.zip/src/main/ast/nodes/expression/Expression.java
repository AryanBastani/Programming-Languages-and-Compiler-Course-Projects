package main.ast.nodes.expression;

import main.ast.nodes.Node;

public abstract class Expression extends Node {
}
