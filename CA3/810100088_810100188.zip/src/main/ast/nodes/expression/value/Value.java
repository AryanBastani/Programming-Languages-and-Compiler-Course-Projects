package main.ast.nodes.expression.value;

import main.ast.nodes.expression.Expression;

public abstract class Value extends Expression {
}
