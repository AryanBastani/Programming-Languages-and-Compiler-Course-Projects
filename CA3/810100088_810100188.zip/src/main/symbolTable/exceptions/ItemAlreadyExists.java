package main.symbolTable.exceptions;

public class ItemAlreadyExists extends Exception{
}
